This is a sample file to check the characteristics you can translate from markdown to docx file.

- [x] Headings
- [x] Bold text
- [x] Italic text
- [x] Bold and Italic text
- [x] Blockquote
- [ ] Ordered list
- [x] Unordered list
- [ ] Horizontal rule
- [x] Links
- [x] Escape characters
- [x] Images
- [x] Table
- [x] Fenced code block
- [ ] Footnote
- [ ] Custom ID for headings
- [ ] Definition list
- [ ] Strikethrough
- [x] Task list
- [ ] Emoji
- [ ] Highlight
- [ ] Subscript
- [ ] Superscript


Now, check how it is working!

### Heading

# H1
## H2
### H3


### Bold
**bold text**


### Italic
*italicized text*


### Bold and Italic
***bold and italicized text***


### Blockquote
> blockquote


### Unordered List
- unordered
- list


### Task List
- [ ] task
- [x] list


### Code Block
```
Fenced Code Block
```


### Table

| Syntax | Description |
| ----------- | ----------- |
| Header | Title |
| Paragraph | Text |


### Links
You can check our repository on [Github Repository](https://github.com/fmmesen/docx2md-wasm)


### And a piece of art!
![art photo](../images/art.jpg)
